<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=devce-width,initial-scale=1.0">
    <title>About us</title>
    <link rel="stylesheet" href="CSS\aboutus.css">
</head>

<body>

<header>
    <img src="Logo.png" >
    <nav class="navigation">
        <a href="Home.php">Home</a>
        <a href="aboutus.php">About</a>
        <a href="Courses.php">Courses</a>
        <a href="contactus.php">Contact us</a>

    </nav>
</header>

<div class="section">
    <div class="container">
        <div class="content-section">
            <div class="title">
                <h1>About Us</h1>
            </div>
            <div class="content">
                <h3>Learn Vault is an E-learning platform. We create simplified and interactive learning experiences. Learn Vault was created in 2019. This is a completely free students resource.<br>We work very hard to ensure Learn Vault remains usefull, updated and interesting. If you find an error or a broken link, please tell us about it. We also keep our users happy and engaged by blocking inappropriate comments with automated profanity filters.</h3>
            </div>

        </div>
        <div class="image-section">
            <img src="CSS\Images\img1.jpg">
        </div>
    </div>
</div>


</body>
</html>

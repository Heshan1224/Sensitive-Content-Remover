<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="CSS\style.css">
</head>
<body>
	<div class="banner">
		<div class="navbar">

			
		</div>

		<div class="content">
			<h1>Sensitive Content Removal</h1>
			<p>This website is</p>

			<div>
				<a href="signup.php"><button type="button"><span></span>Sign up</button></a>
				<a href="login.php"><button type="button"><span></span>Login</button></a>
			</div>
		</div>

	</div>

</body>
</html>

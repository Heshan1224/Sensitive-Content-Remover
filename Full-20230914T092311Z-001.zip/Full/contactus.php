<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Contact us</title>
        <link rel="stylesheet" href="CSS\contactus.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
    </head>

    <body>

        <header>
            <img src="Logo.png" alt="LOGO">
            <nav class="navigation">
              <a href="Home.php">Home</a>
              <a href="aboutus.php">About</a>
              <a href="Courses.php">Courses</a>
              <a href="contactus.php">Contact us</a>
            
            </nav>
        </header>


        <div class="container">
            <h1>Connect With Us</h1>
            <p>We would love to respond to your queries and help you succeed.<br>Feel free to get in touch with us</p>
        <div class="contact-box">
            <div class="contact-left">
                <h3>Sent your request</h3>
                <form>
                    <div class="input-row">
                        <div class="input-group">
                            <label>Name</label>
                            <input type="text" placeholder="Chamika Heshan">
                        </div>

                        <div class="input-group">
                            <label>Phone</label>
                            <input type="text" placeholder="+9470 5250 433">
                        </div>
                    </div>

                    <div class="input-row">
                        <div class="input-group">
                            <label>Email</label>
                            <input type="email" placeholder="chamikaheshan2015@gmail.com">
                        </div>

                        <div class="input-group">
                            <label>Phone</label>
                            <input type="text" placeholder="+9470 5250 433">
                        </div>
                    </div>

                    <label>Message</label>
                    <textarea rows="5" placeholder="Your Message"></textarea>

                    <button type="submit">SEND</button>

                </form>
            </div>
            <div class="contact-right">
                <h3>Reach us</h3>

                <table>
                    <tr>
                        <td>Email</td>
                        <td>contactus@example.com</td>
                    </tr>

                    <tr>
                        <td>Phone</td>
                        <td>+9470 5250 433</td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>Near the hospital<br>
                        Wanduruppa Rd<br>
                    Ambalantota</td>
                    </tr>

                </table>

            </div>
        </div>



        </div>


    </body>

</html>
